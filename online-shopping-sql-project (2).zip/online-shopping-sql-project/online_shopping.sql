-- Online Shopping Management System
-- Practice project using MySQL

CREATE DATABASE IF NOT EXISTS online_shopping;
USE online_shopping;

-- Start fresh each time this practice script is run
DROP VIEW IF EXISTS order_summary;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

-- Customer information
CREATE TABLE customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    city VARCHAR(50),
    joined_on DATE
);

-- Products available in the store
CREATE TABLE products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    product_name VARCHAR(100) NOT NULL,
    category VARCHAR(50),
    price DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL
);

-- One customer can place many orders
CREATE TABLE orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT NOT NULL,
    order_date DATE NOT NULL,
    status VARCHAR(20) NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- Products included in each order
CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Add sample customers (fictional data)
INSERT INTO customers (full_name, email, city, joined_on) VALUES
('Aarav Sharma', 'aarav@example.com', 'Pune', '2025-01-12'),
('Mira Patel', 'mira@example.com', 'Mumbai', '2025-02-03'),
('Kabir Singh', 'kabir@example.com', 'Delhi', '2025-02-20'),
('Anaya Deshmukh', 'anaya@example.com', 'Pune', '2025-03-15'),
('Ishaan Rao', 'ishaan@example.com', 'Bengaluru', '2025-04-01');

-- Add sample products
INSERT INTO products (product_name, category, price, stock) VALUES
('Wireless Mouse', 'Electronics', 799.00, 35),
('Mechanical Keyboard', 'Electronics', 2499.00, 18),
('Steel Water Bottle', 'Home', 499.00, 50),
('Notebook Set', 'Stationery', 299.00, 80),
('Desk Lamp', 'Home', 1299.00, 22),
('USB-C Cable', 'Electronics', 399.00, 60);

-- Add sample orders
INSERT INTO orders (customer_id, order_date, status) VALUES
(1, '2025-05-01', 'Delivered'),
(2, '2025-05-03', 'Shipped'),
(1, '2025-05-10', 'Delivered'),
(3, '2025-05-12', 'Pending'),
(4, '2025-05-15', 'Delivered'),
(5, '2025-05-18', 'Cancelled');

-- Add the products for each order
INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
(1, 1, 1, 799.00),
(1, 4, 2, 299.00),
(2, 2, 1, 2499.00),
(2, 6, 2, 399.00),
(3, 5, 1, 1299.00),
(3, 3, 2, 499.00),
(4, 1, 2, 799.00),
(5, 4, 3, 299.00),
(5, 3, 1, 499.00),
(6, 6, 1, 399.00);

-- 1. Show orders with customer names
SELECT o.order_id, c.full_name, o.order_date, o.status
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
ORDER BY o.order_date;

-- 2. Calculate each order's total amount
SELECT o.order_id, c.full_name,
       SUM(oi.quantity * oi.unit_price) AS order_total
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY o.order_id, c.full_name
ORDER BY o.order_id;

-- 3. Total spending for each customer (cancelled orders are excluded)
SELECT c.customer_id, c.full_name,
       COALESCE(SUM(oi.quantity * oi.unit_price), 0) AS total_spent
FROM customers c
LEFT JOIN orders o
    ON c.customer_id = o.customer_id AND o.status <> 'Cancelled'
LEFT JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY c.customer_id, c.full_name
ORDER BY total_spent DESC;

-- 4. Find products sold in the highest quantities
SELECT p.product_name, SUM(oi.quantity) AS units_sold
FROM products p
JOIN order_items oi ON p.product_id = oi.product_id
JOIN orders o ON oi.order_id = o.order_id
WHERE o.status <> 'Cancelled'
GROUP BY p.product_id, p.product_name
ORDER BY units_sold DESC;

-- 5. Count orders by status
SELECT status, COUNT(*) AS order_count
FROM orders
GROUP BY status
ORDER BY order_count DESC;

-- 6. Find customers who have not placed an order
SELECT c.customer_id, c.full_name
FROM customers c
LEFT JOIN orders o ON c.customer_id = o.customer_id
WHERE o.order_id IS NULL;

-- 7. Calculate order value for each month (cancelled orders excluded)
SELECT DATE_FORMAT(o.order_date, '%Y-%m') AS order_month,
       SUM(oi.quantity * oi.unit_price) AS order_value
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
WHERE o.status <> 'Cancelled'
GROUP BY DATE_FORMAT(o.order_date, '%Y-%m')
ORDER BY order_month;

-- 8. Find products with fewer than 25 items in stock
SELECT product_name, stock
FROM products
WHERE stock < 25
ORDER BY stock;

-- 9. Create a view to show order details and totals
CREATE VIEW order_summary AS
SELECT o.order_id, c.full_name, o.order_date, o.status,
       COALESCE(SUM(oi.quantity * oi.unit_price), 0) AS order_total
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
LEFT JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY o.order_id, c.full_name, o.order_date, o.status;

-- View the summary
SELECT * FROM order_summary ORDER BY order_id;
